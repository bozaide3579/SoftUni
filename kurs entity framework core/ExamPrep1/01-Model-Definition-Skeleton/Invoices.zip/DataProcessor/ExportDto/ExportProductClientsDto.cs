﻿using System;
namespace Invoices.DataProcessor.ExportDto
{
	public class ExportProductClientsDto
	{
		public string Name { get; set; }

		public string NumberVat { get; set; }
	}
}

