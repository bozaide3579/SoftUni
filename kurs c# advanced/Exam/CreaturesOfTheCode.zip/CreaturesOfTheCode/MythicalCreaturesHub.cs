﻿namespace CreaturesOfTheCode
{
    public class MythicalCreaturesHub
    {

    }
}
