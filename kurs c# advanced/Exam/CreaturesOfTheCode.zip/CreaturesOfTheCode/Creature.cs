﻿namespace CreaturesOfTheCode
{
    public class Creature
    {

    }
}
