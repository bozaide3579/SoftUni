﻿namespace CocktailBar
{
    public class Menu
    {
    }
}
