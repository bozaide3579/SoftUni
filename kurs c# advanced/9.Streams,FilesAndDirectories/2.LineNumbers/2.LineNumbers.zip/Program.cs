﻿namespace OddLines
{
	public class OddLines
	{
		static void Main()
		{
			string inputFilePath = @"..\..\..\Files\input.txt";
			string outputFilePath = @"..\..\..\Files\output.txt";

			ExtractOddLines(inputFilePath, outputFilePath);
		}

		public static void ExtractOddLines(string inputFilePath, string outputFilePath)
		{
			using (StreamWriter writer = new StreamWriter(outputFilePath))
			{
				using (StreamReader reader = new StreamReader(inputFilePath))
				{

					string line;
					int lineNumber = 1;
					while ((line = reader.ReadLine()) != null)
					{
						writer.WriteLine($"{lineNumber++}. {line}");
					}
				}
			}
		}
	}
}

